package __PKG__;

import android.Manifest;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;

import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;

import com.k2fsa.sherpa.onnx.KeywordSpotter;
import com.k2fsa.sherpa.onnx.KeywordSpotterConfig;
import com.k2fsa.sherpa.onnx.OnlineModelConfig;
import com.k2fsa.sherpa.onnx.OnlineStream;
import com.k2fsa.sherpa.onnx.OnlineTransducerModelConfig;

/** Offline Sherpa-ONNX keyword spotting for "Hey Helper". */
@CapacitorPlugin(
    name = "WakeWord",
    permissions = { @Permission(strings = { Manifest.permission.RECORD_AUDIO }, alias = "microphone") }
)
public class WakeWordPlugin extends Plugin {
    private static final int SAMPLE_RATE = 16000;
    private static final int CHUNK_SAMPLES = SAMPLE_RATE / 10; // 100 ms
    private static final String DIR = "kws/";

    private KeywordSpotter spotter;
    private volatile boolean running = false;
    private Thread worker;

    @PluginMethod
    public void start(PluginCall call) {
        if (getPermissionState("microphone") != PermissionState.GRANTED) {
            requestPermissionForAlias("microphone", call, "micPermissionCallback");
            return;
        }
        begin(call);
    }

    @PermissionCallback
    private void micPermissionCallback(PluginCall call) {
        if (getPermissionState("microphone") == PermissionState.GRANTED) {
            begin(call);
        } else {
            call.reject("Microphone permission denied");
            emitStatus("error", "Microphone permission denied");
        }
    }

    private synchronized void begin(PluginCall call) {
        if (running) {
            call.resolve();
            emitStatus("listening", "Wake-word listener is already running");
            return;
        }

        try {
            emitStatus("loading", "Loading the Hey Helper wake-word model");
            if (spotter == null) {
                OnlineTransducerModelConfig transducer = new OnlineTransducerModelConfig();
                transducer.setEncoder(DIR + "encoder.onnx");
                transducer.setDecoder(DIR + "decoder.onnx");
                transducer.setJoiner(DIR + "joiner.onnx");

                OnlineModelConfig model = new OnlineModelConfig();
                model.setTransducer(transducer);
                model.setTokens(DIR + "tokens.txt");
                model.setModelType("zipformer2");
                model.setNumThreads(1);

                KeywordSpotterConfig config = new KeywordSpotterConfig();
                config.setModelConfig(model);
                config.setKeywordsFile(DIR + "keywords.txt");
                spotter = new KeywordSpotter(getContext().getAssets(), config);
            }

            int minBytes = AudioRecord.getMinBufferSize(
                SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            if (minBytes == AudioRecord.ERROR || minBytes == AudioRecord.ERROR_BAD_VALUE) {
                minBytes = CHUNK_SAMPLES * 2;
            }
            int bufferBytes = Math.max(minBytes, CHUNK_SAMPLES * 4);
            final AudioRecord record = new AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufferBytes
            );

            if (record.getState() != AudioRecord.STATE_INITIALIZED) {
                record.release();
                emitStatus("error", "Android could not initialize the microphone recorder");
                call.reject("Could not initialize the microphone recorder");
                return;
            }

            running = true;
            worker = new Thread(() -> listen(record), "wake-word");
            worker.setPriority(Thread.NORM_PRIORITY);
            worker.start();
            call.resolve();
        } catch (Throwable t) {
            running = false;
            String message = "Wake-word initialization failed: " + errorText(t);
            emitStatus("error", message);
            call.reject(message);
        }
    }

    private void listen(AudioRecord record) {
        boolean detected = false;
        boolean startedNormally = false;
        String detectedKeyword = "";
        String failure = null;
        OnlineStream stream = null;
        long decodedFrames = 0;
        long lastDiagnostic = System.currentTimeMillis();
        int peakSinceDiagnostic = 0;

        try {
            stream = spotter.createStream("");
            record.startRecording();
            if (record.getRecordingState() != AudioRecord.RECORDSTATE_RECORDING) {
                throw new IllegalStateException("AudioRecord did not enter RECORDSTATE_RECORDING");
            }
            startedNormally = true;
            emitStatus("listening", "Microphone is active; waiting for Hey Helper");

            short[] pcm = new short[CHUNK_SAMPLES];
            while (running) {
                int n = record.read(pcm, 0, pcm.length, AudioRecord.READ_BLOCKING);
                if (n == 0) continue;
                if (n < 0) {
                    throw new IllegalStateException("Microphone read failed with code " + n);
                }

                float[] samples = new float[n];
                int peak = 0;
                for (int i = 0; i < n; i++) {
                    int abs = Math.abs((int) pcm[i]);
                    if (abs > peak) peak = abs;
                    samples[i] = pcm[i] / 32768.0f;
                }
                if (peak > peakSinceDiagnostic) peakSinceDiagnostic = peak;
                stream.acceptWaveform(samples, SAMPLE_RATE);

                // Check the result immediately after EVERY decode. Checking only after the
                // entire isReady() loop can miss a short-lived keyword result.
                while (running && spotter.isReady(stream)) {
                    spotter.decode(stream);
                    decodedFrames++;
                    String keyword = spotter.getResult(stream).getKeyword();
                    if (keyword != null && !keyword.trim().isEmpty()) {
                        detectedKeyword = keyword.trim();
                        spotter.reset(stream);
                        detected = true;
                        break;
                    }
                }
                if (detected) break;

                long now = System.currentTimeMillis();
                if (now - lastDiagnostic >= 5000) {
                    emitStatus("listening", "Still listening; mic peak=" + peakSinceDiagnostic
                        + "/32768, decoded frames=" + decodedFrames);
                    peakSinceDiagnostic = 0;
                    lastDiagnostic = now;
                }
            }
        } catch (Throwable t) {
            if (running) failure = "Wake-word listener error: " + errorText(t);
        } finally {
            boolean wasRunning = running;
            running = false;
            try {
                if (record.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) record.stop();
            } catch (Throwable ignored) {}
            try { record.release(); } catch (Throwable ignored) {}
            try { if (stream != null) stream.release(); } catch (Throwable ignored) {}
            if (failure != null) {
                emitStatus("error", failure);
            } else if (!detected && wasRunning && startedNormally) {
                emitStatus("error", "Wake-word listener stopped before detecting a keyword");
            }
        }

        if (detected) {
            final String keyword = detectedKeyword;
            emitStatus("detected", "Detected keyword: " + keyword);
            JSObject event = new JSObject();
            event.put("keyword", keyword);
            runOnMainThread(() -> notifyListeners("wake", event));
        }
    }

    @PluginMethod
    public void stop(PluginCall call) {
        running = false;
        Thread t = worker;
        if (t != null && t != Thread.currentThread()) {
            try { t.join(1500); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        }
        emitStatus("stopped", "Wake-word listener stopped");
        call.resolve();
    }

    private String errorText(Throwable t) {
        String message = t.getMessage();
        return t.getClass().getSimpleName() + (message == null || message.trim().isEmpty() ? "" : ": " + message);
    }

    private void emitStatus(String state, String message) {
        JSObject event = new JSObject();
        event.put("state", state);
        event.put("message", message);
        runOnMainThread(() -> notifyListeners("status", event));
    }

    private void runOnMainThread(Runnable action) {
        if (getActivity() != null) getActivity().runOnUiThread(action);
        else action.run();
    }
}
