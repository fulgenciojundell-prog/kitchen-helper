/* Makes the app's Web Speech code work inside the Android app (Capacitor).
   Android WebView has no SpeechRecognition and a silent speechSynthesis, so on a native build
   we provide drop-in replacements backed by two Capacitor plugins. In a normal browser this
   file does nothing.
   DEBUG shows a small status strip at the bottom of the screen while we tune voice on real phones. */
(function () {
  var cap = window.Capacitor;
  if (!cap || !cap.isNativePlatform || !cap.isNativePlatform()) return;

  var lines = [], logEl = null, visible = false;
  function paint() {
    if (!document.body) return;
    if (!logEl) {
      logEl = document.createElement('div');
      logEl.style.cssText = 'position:fixed;left:0;right:0;bottom:0;z-index:99999;font:10px/1.3 monospace;color:#fff;background:rgba(0,0,0,.65);padding:2px 6px;pointer-events:none;white-space:pre-wrap';
      document.body.appendChild(logEl);
    }
    logEl.style.display = visible ? 'block' : 'none';
    logEl.textContent = lines.join('\n');
  }
  window.__nsLog = function (m) {
    lines.push(m); if (lines.length > 8) lines.shift();
    if (visible) { if (document.body) paint(); }
  };
  // Hidden by default. Settings > Voice gets a "Show voice log" button for troubleshooting.
  document.addEventListener('DOMContentLoaded', function () {
    var anchor = document.getElementById('voiceTest');
    if (!anchor || !anchor.parentNode) return;
    var b = document.createElement('button');
    b.type = 'button'; b.className = anchor.className; b.style.marginLeft = '8px';
    b.textContent = 'Show voice log';
    b.addEventListener('click', function () {
      visible = !visible; b.textContent = visible ? 'Hide voice log' : 'Show voice log'; paint();
    });
    anchor.parentNode.insertBefore(b, anchor.nextSibling);
  });
  var log = window.__nsLog;
})();

(function () {
  var cap = window.Capacitor;
  if (!cap || !cap.isNativePlatform || !cap.isNativePlatform()) return;
  var log = window.__nsLog || function () {};
  var P = (cap.Plugins && cap.Plugins.SpeechRecognition) ||
          (typeof cap.registerPlugin === 'function' ? cap.registerPlugin('SpeechRecognition') : null);
  if (!P) { log('speech plugin missing'); return; }

  var gen = 0, availChecked = false, availOK = true, failStreak = 0;
  function tmo(p, ms, label) {
    return new Promise(function (res, rej) {
      var t = setTimeout(function () { rej(new Error('timeout ' + label)); }, ms);
      Promise.resolve(p).then(function (v) { clearTimeout(t); res(v); }, function (e) { clearTimeout(t); rej(e); });
    });
  }
  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

  function NativeSR() {
    this.lang = 'en-US'; this.interimResults = true; this.continuous = false; this.maxAlternatives = 1;
    this.onstart = this.onresult = this.onerror = this.onend = null;
    this._active = false; this._aborted = false; this._closed = true; this._stopped = false;
    this._handles = []; this._last = []; this._close = null;
  }
  NativeSR.prototype._emit = function (name, ev) {
    try { if (typeof this[name] === 'function') this[name](ev || {}); } catch (e) { console.error(e); }
  };
  function results(matches, isFinal) {
    var alts = matches.map(function (t) { return { transcript: t, confidence: 0.9 }; });
    alts.isFinal = !!isFinal;
    return { results: [alts], resultIndex: 0 };
  }

  NativeSR.prototype.start = function () {
    var self = this;
    if (self._active) throw new Error('already started');
    self._active = true; self._aborted = false; self._closed = false; self._stopped = false;
    self._last = []; self._handles = [];
    var my = ++gen, started = false, grace = null, watchdog = null, t0 = Date.now(), firstHeard = false;
    log('listen: start #' + my);

    function markStarted() { if (!started) { started = true; log('listen: mic open'); self._emit('onstart'); } }
    function close(errName) {
      if (self._closed) return;
      self._closed = true;
      clearTimeout(grace); clearTimeout(watchdog);
      self._handles.forEach(function (h) { try { h.remove(); } catch (e) {} });
      self._handles = [];
      try { P.stop(); } catch (e) {}              // always free the recognizer
      if (errName) self._emit('onerror', { error: errName });
      else if (!self._aborted && self._last.length) { log('listen: result "' + self._last[0] + '"'); self._emit('onresult', results(self._last, true)); }
      else log('listen: ended, nothing heard');
      if (!errName && !self._aborted) {
        if (self._last.length) failStreak = 0;
        else if (Date.now() - t0 < 3000) failStreak++;   // engine gave up almost immediately: back off before retrying
      }
      self._active = false;
      log('listen: closed');
      self._emit('onend');
    }
    self._close = close;

    (async function () {
      try {
        var perm = await tmo(P.requestPermissions(), 30000, 'permission');
        log('listen: perm ' + (perm && perm.speechRecognition));
        if (self._closed) return;
        if (!perm || perm.speechRecognition !== 'granted') { close('not-allowed'); return; }
        if (!availChecked) {
          var a = await tmo(P.available(), 4000, 'available'); availChecked = true; availOK = !(a && a.available === false);
        }
        if (!availOK) { log('no speech service on phone'); close('service-not-allowed'); return; }
        try { await tmo(P.stop(), 700, 'reset'); } catch (e) {}   // reset engine; never wait on it forever
        await sleep(300 + Math.min(failStreak, 3) * 500);
        if (self._closed) return;

        self._handles.push(await tmo(P.addListener('partialResults', function (d) {
          if (self._closed || my !== gen || !d || !d.matches || !d.matches.length) return;
          markStarted();
          if (!firstHeard) { firstHeard = true; log('listen: heard "' + String(d.matches[0]).slice(0, 36) + '"'); }
          self._last = d.matches;
          if (self.interimResults && !self._aborted) self._emit('onresult', results(d.matches, false));
          if (self._stopped) { clearTimeout(grace); grace = setTimeout(function () { close(); }, 500); }
        }), 4000, 'listener1'));
        self._handles.push(await tmo(P.addListener('listeningState', function (d) {
          if (self._closed || my !== gen || !d) return;
          if (d.status === 'started') markStarted();
          if (d.status === 'stopped') {
            log('listen: engine stopped after ' + ((Date.now() - t0) / 1000).toFixed(1) + 's');
            self._stopped = true;
            clearTimeout(grace);
            grace = setTimeout(function () { close(); }, 800);   // final text can arrive just after "stopped"
          }
        }), 4000, 'listener2'));
        watchdog = setTimeout(function () { log('listen: timeout'); close(self._last.length ? null : 'no-speech'); }, 20000);
        if (self._closed) return;
        log('listen: calling start');
        // Do not wait for start() to settle: the mic-open events tell us it worked.
        Promise.resolve(P.start({ language: self.lang, maxResults: Math.max(1, self.maxAlternatives || 1), partialResults: true, popup: false }))
          .then(function () { markStarted(); })
          .catch(function (e) {
            var m = String(e && e.message || e);
            log('listen: start failed ' + m);
            close(/permission/i.test(m) ? 'not-allowed' : 'network');
          });
      } catch (e) {
        var msg = String(e && e.message || e);
        log('listen: error ' + msg);
        close(/permission/i.test(msg) ? 'not-allowed' : 'network');
      }
    })();
  };

  NativeSR.prototype.stop = function () {
    var self = this;
    if (!self._active || self._closed) return;
    self._stopped = true;
    try { P.stop(); } catch (e) {}
    setTimeout(function () { if (self._close) self._close(); }, 800);
  };
  NativeSR.prototype.abort = function () {
    this._aborted = true;
    if (this._close) this._close();
  };

  window.SpeechRecognition = NativeSR;
  window.webkitSpeechRecognition = NativeSR;
})();

/* Spoken answers: Android WebView's speechSynthesis is silent/unreliable, so on a native
   build replace it with @capacitor-community/text-to-speech behind the same interface. */
(function () {
  var cap = window.Capacitor;
  if (!cap || !cap.isNativePlatform || !cap.isNativePlatform()) return;
  var T = (cap.Plugins && cap.Plugins.TextToSpeech) ||
          (typeof cap.registerPlugin === 'function' ? cap.registerPlugin('TextToSpeech') : null);
  if (!T) return;

  function Utterance(text) {
    this.text = text || ''; this.lang = ''; this.rate = 1; this.pitch = 1; this.volume = 1;
    this.voice = null; this.onstart = this.onend = this.onerror = null; this._cancelled = false;
  }

  var voices = [], listeners = [], current = null;

  var synth = {
    speaking: false, pending: false, paused: false,
    getVoices: function () { return voices; },
    addEventListener: function (t, fn) { if (t === 'voiceschanged') listeners.push(fn); },
    removeEventListener: function (t, fn) { listeners = listeners.filter(function (f) { return f !== fn; }); },
    cancel: function () {
      var wasSpeaking = synth.speaking;
      if (current) current._cancelled = true;   // cancelled utterances stay silent (no callbacks)
      current = null; synth.speaking = false;
      if (wasSpeaking) { try { T.stop(); } catch (e) {} }
    },
    speak: function (u) {
      u._cancelled = false; u._retried = false; current = u; synth.speaking = true;
      var opts = {
        text: u.text,
        lang: (u.voice && u.voice.lang) || u.lang || navigator.language || 'en-US',
        rate: u.rate || 1, pitch: u.pitch || 1, volume: u.volume == null ? 1 : u.volume,
        category: 'ambient', queueStrategy: 0
      };
      if (u.voice && typeof u.voice._idx === 'number') opts.voice = u.voice._idx;
      if (window.__nsLog) window.__nsLog('speak: ' + u.text.slice(0, 40));
      try { if (typeof u.onstart === 'function') u.onstart({}); } catch (e) {}
      synth._speakOpts(u, opts);
    },
    _speakOpts: function (u, opts) {
      Promise.resolve(T.speak(opts)).then(function () {
        if (window.__nsLog) window.__nsLog('speak: finished' + (u._cancelled ? ' (cancelled)' : ''));
        if (u._cancelled) return;
        if (current === u) { current = null; synth.speaking = false; }
        setTimeout(function () { try { if (typeof u.onend === 'function') u.onend({}); } catch (e) { console.error(e); } }, 400);
      }).catch(function (err) {
        if (window.__nsLog) window.__nsLog('speak: FAILED ' + String(err && err.message || err).slice(0, 60));
        if (u._cancelled) return;
        if (!u._retried) {   // one plain retry: default voice and language
          u._retried = true;
          if (window.__nsLog) window.__nsLog('speak: retrying with default voice');
          synth._speakOpts(u, { text: u.text, rate: u.rate || 1, pitch: 1, category: 'ambient', queueStrategy: 0 });
          return;
        }
        if (current === u) { current = null; synth.speaking = false; }
        try { if (typeof u.onerror === 'function') u.onerror({ error: String(err && err.message || err) }); } catch (e) { console.error(e); }
      });
    }
  };

  try {
    Object.defineProperty(window, 'speechSynthesis', { value: synth, configurable: true });
  } catch (e) { window.speechSynthesis = synth; }
  window.SpeechSynthesisUtterance = Utterance;

  // Load the phone's voices, then tell the app (it rebuilds its voice list on 'voiceschanged').
  function loadVoices() {
    Promise.resolve(T.getSupportedVoices()).then(function (r) {
      voices = ((r && r.voices) || []).map(function (v, i) {
        return { name: v.name || v.voiceURI || ('Voice ' + (i + 1)), lang: v.lang || 'en-US',
                 voiceURI: v.voiceURI || '', localService: v.localService !== false,
                 default: !!v.default, _idx: i };
      });
      listeners.slice().forEach(function (fn) { try { fn({}); } catch (e) {} });
    }).catch(function () {});
  }
  loadVoices();
  setTimeout(loadVoices, 1500);   // some phones report voices late
})();
