package __PKG__;

import android.Manifest;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;

import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;

import com.k2fsa.sherpa.onnx.KeywordSpotter;
import com.k2fsa.sherpa.onnx.KeywordSpotterConfig;
import com.k2fsa.sherpa.onnx.OnlineModelConfig;
import com.k2fsa.sherpa.onnx.OnlineStream;
import com.k2fsa.sherpa.onnx.OnlineTransducerModelConfig;

import java.util.Arrays;

/**
 * Offline wake-word detector ("hey helper") using sherpa-onnx keyword spotting.
 * start(): opens the mic and listens. On detection it releases the mic, then fires a "wake" event.
 * stop(): releases the mic.
 */
@CapacitorPlugin(
    name = "WakeWord",
    permissions = { @Permission(strings = { Manifest.permission.RECORD_AUDIO }, alias = "microphone") }
)
public class WakeWordPlugin extends Plugin {
    private static final int SAMPLE_RATE = 16000;
    private static final String DIR = "kws/";

    private KeywordSpotter spotter;
    private volatile boolean running = false;
    private Thread worker;

    @PluginMethod
    public void start(PluginCall call) {
        if (getPermissionState("microphone") != PermissionState.GRANTED) {
            requestPermissionForAlias("microphone", call, "micPermissionCallback");
            return;
        }
        begin(call);
    }

    @PermissionCallback
    private void micPermissionCallback(PluginCall call) {
        if (getPermissionState("microphone") == PermissionState.GRANTED) {
            begin(call);
        } else {
            call.reject("Microphone permission denied");
        }
    }

    private synchronized void begin(PluginCall call) {
        if (running) {
            call.resolve();
            return;
        }
        try {
            if (spotter == null) {
                OnlineTransducerModelConfig transducer = new OnlineTransducerModelConfig();
                transducer.setEncoder(DIR + "encoder.onnx");
                transducer.setDecoder(DIR + "decoder.onnx");
                transducer.setJoiner(DIR + "joiner.onnx");

                OnlineModelConfig model = new OnlineModelConfig();
                model.setTransducer(transducer);
                model.setTokens(DIR + "tokens.txt");
                model.setModelType("zipformer2");
                model.setNumThreads(1);

                KeywordSpotterConfig config = new KeywordSpotterConfig();
                config.setModelConfig(model);
                config.setKeywordsFile(DIR + "keywords.txt");

                spotter = new KeywordSpotter(getContext().getAssets(), config);
            }

            int minBytes = AudioRecord.getMinBufferSize(
                SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            int bufBytes = Math.max(minBytes, SAMPLE_RATE * 2);   // at least one second
            final AudioRecord record = new AudioRecord(
                MediaRecorder.AudioSource.MIC, SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufBytes);
            if (record.getState() != AudioRecord.STATE_INITIALIZED) {
                record.release();
                call.reject("Could not open the microphone");
                return;
            }

            running = true;
            worker = new Thread(new Runnable() {
                @Override
                public void run() {
                    listen(record);
                }
            }, "wake-word");
            worker.start();
            call.resolve();
        } catch (Throwable t) {
            running = false;
            call.reject("Wake word init failed: " + t);
        }
    }

    private void listen(AudioRecord record) {
        boolean detected = false;
        OnlineStream stream = null;
        try {
            stream = spotter.createStream("");
            record.startRecording();
            short[] buf = new short[SAMPLE_RATE / 10];   // 100 ms
            float[] samples = new float[buf.length];
            while (running) {
                int n = record.read(buf, 0, buf.length);
                if (n < 0) break;
                if (n == 0) continue;
                for (int i = 0; i < n; i++) samples[i] = buf[i] / 32768.0f;
                stream.acceptWaveform(n == samples.length ? samples : Arrays.copyOf(samples, n), SAMPLE_RATE);
                while (spotter.isReady(stream)) spotter.decode(stream);
                String keyword = spotter.getResult(stream).getKeyword();
                if (keyword != null && keyword.length() > 0) {
                    spotter.reset(stream);
                    detected = true;
                    break;
                }
            }
        } catch (Throwable t) {
            // fall through: release everything
        } finally {
            running = false;
            try { record.stop(); } catch (Throwable ignored) {}
            try { record.release(); } catch (Throwable ignored) {}
            try { if (stream != null) stream.release(); } catch (Throwable ignored) {}
        }
        if (detected) {
            JSObject ev = new JSObject();
            ev.put("keyword", "hey helper");
            notifyListeners("wake", ev);
        }
    }

    @PluginMethod
    public void stop(PluginCall call) {
        running = false;
        Thread t = worker;
        if (t != null && t != Thread.currentThread()) {
            try { t.join(1500); } catch (InterruptedException ignored) {}
        }
        call.resolve();
    }
}
