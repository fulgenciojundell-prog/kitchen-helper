#!/usr/bin/env bash
# Builds the Android app WITH the offline "hey helper" wake word. Runs on GitHub (see build-wakeword.yml).
set -euo pipefail
exec > >(tee build.log) 2>&1

SHERPA_VERSION=1.13.8
MODEL=sherpa-onnx-kws-zipformer-gigaspeech-3.3M-2024-01-01

echo "== 1/6 web app + capacitor"
npm install @capacitor/core @capacitor/android @capacitor-community/speech-recognition @capacitor-community/text-to-speech @fontsource-variable/fraunces @fontsource-variable/inter
npm install -D @capacitor/cli
npx cap add android
npm run sync

echo "== 2/6 sherpa-onnx library"
mkdir -p android/app/libs
curl -fSL -o android/app/libs/sherpa-onnx.aar \
  "https://github.com/k2-fsa/sherpa-onnx/releases/download/v${SHERPA_VERSION}/sherpa-onnx-${SHERPA_VERSION}.aar"
ls -l android/app/libs

echo "== 3/6 keyword model"
ASSETS=android/app/src/main/assets/kws
mkdir -p "$ASSETS"
curl -fSL -o model.tar.bz2 "https://github.com/k2-fsa/sherpa-onnx/releases/download/kws-models/${MODEL}.tar.bz2"
tar xjf model.tar.bz2
ls -l "$MODEL"
SUFFIX=epoch-12-avg-2-chunk-16-left-64.int8.onnx
cp "$MODEL/encoder-$SUFFIX" "$ASSETS/encoder.onnx"
cp "$MODEL/decoder-$SUFFIX" "$ASSETS/decoder.onnx"
cp "$MODEL/joiner-$SUFFIX"  "$ASSETS/joiner.onnx"
cp "$MODEL/tokens.txt"      "$ASSETS/tokens.txt"

echo "== 4/6 keyword list for 'hey helper'"
python3 -m pip install --quiet sherpa-onnx sentencepiece
printf 'HEY HELPER :1.5 #0.25\n' > raw_keywords.txt
sherpa-onnx-cli text2token --tokens "$MODEL/tokens.txt" --tokens-type bpe --bpe-model "$MODEL/bpe.model" raw_keywords.txt "$ASSETS/keywords.txt"
echo "keywords.txt:"; cat "$ASSETS/keywords.txt"

echo "== 5/6 native plugin"
MA=$(find android/app/src/main/java -name 'MainActivity.java' | head -n 1)
if [ -z "$MA" ]; then echo "MainActivity.java not found (project template changed?)"; find android/app/src/main -name 'MainActivity*'; exit 1; fi
DIR=$(dirname "$MA")
PKG=$(grep -m1 '^package ' "$MA" | sed -E 's/^package ([^;]+);.*/\1/')
echo "package: $PKG, dir: $DIR"
sed "s/__PKG__/$PKG/" wakeword/WakeWordPlugin.java > "$DIR/WakeWordPlugin.java"
sed "s/__PKG__/$PKG/" wakeword/MainActivity.java   > "$MA"
cat >> android/app/build.gradle <<'GRADLE'

dependencies {
    implementation files('libs/sherpa-onnx.aar')
    implementation 'org.jetbrains.kotlin:kotlin-stdlib:1.9.24'
}

android {
    defaultConfig {
        ndk {
            abiFilters 'arm64-v8a'
        }
    }
}
GRADLE

echo "== 6/6 build APK"
cd android
chmod +x gradlew
./gradlew assembleDebug --stacktrace
echo "DONE"
