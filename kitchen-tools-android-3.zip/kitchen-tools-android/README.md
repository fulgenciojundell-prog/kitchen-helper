# Kitchen Tools: Android app (Capacitor, fully offline)

Your web app lives in `web/` (unchanged except it's no longer using the service worker). `npm run sync` builds it into `www/` and copies it into the Android project.

## You need
- Node 20+ and npm
- Android Studio (includes the Android SDK) and JDK 21
  (check the current Capacitor docs if versions have moved on)

## One-time setup
```
npm install @capacitor/core @capacitor/android @capacitor-community/speech-recognition @capacitor-community/text-to-speech @fontsource-variable/fraunces @fontsource-variable/inter
npm install -D @capacitor/cli
npx cap add android
npm run sync
```
Let npm pick matching versions. If it warns the speech plugin needs a different Capacitor major, install the plugin version that matches.

## Run / build
- `npm run open` opens Android Studio. Press Run to launch on a phone or emulator.
- Test APK: Build > Build Bundle(s) / APK(s) > Build APK(s).
- Play Store: Build > Generate Signed Bundle (AAB). Needs your own signing key.

## After you edit the web app
Edit files in `web/`, then `npm run sync`.

## Before publishing
- Change `appId` in `capacitor.config.json` (`com.coffeeco.kitchentools` is a placeholder). It can't change after you publish.
- Replace the launcher icon in Android Studio: right-click `res` > New > Image Asset, using `web/icon-512.png`.

## What's different from the website
- **Voice input / hands-free:** Android WebView has no Web Speech API, so `web/native-speech.js` makes the plugin look like it. This is untested on a real device. Expect to tune hands-free mode (Android's recognizer stops after each pause, so the app reopens it, and some phones beep on each restart).
- **Spoken answers:** use the phone's text-to-speech through `@capacitor-community/text-to-speech` (the WebView's own speech output is silent).
- **Settings > Refresh app** is meaningless offline; the app updates when you install a new build.
- Saved history/custom ingredients are stored inside the app and don't carry over from the website.

## Build online (no Android Studio)
1. Create a free GitHub account and a new repository.
2. Upload everything in this folder, including the hidden `.github` folder, to the repo's main branch.
3. Open the repo's **Actions** tab. The "Build Android APK" run starts by itself (or click Run workflow).
4. When it finishes (about 5-10 minutes), open the run and download **kitchen-tools-apk** at the bottom.
5. Unzip it, send `app-debug.apk` to your phone, and install it (Android will ask you to allow installs from that source).
The debug APK is for your own phone. A Play Store release needs a signed build.
