// Adds microphone permission + speech-service visibility to the Android manifest (safe to re-run).
import fs from 'node:fs';
const f = 'android/app/src/main/AndroidManifest.xml';
if (!fs.existsSync(f)) { console.log('No android/ folder yet - run: npx cap add android'); process.exit(0); }
let x = fs.readFileSync(f, 'utf8');
if (!x.includes('android.permission.RECORD_AUDIO'))
  x = x.replace('</manifest>', '    <uses-permission android:name="android.permission.RECORD_AUDIO" />\n</manifest>');
if (!x.includes('android.speech.RecognitionService'))
  x = x.replace('</manifest>', '    <queries>\n        <intent><action android:name="android.speech.RecognitionService" /></intent>\n    </queries>\n</manifest>');
fs.writeFileSync(f, x);
console.log('AndroidManifest patched');
