// Builds www/ from web/: bundles fonts locally, drops the service worker, injects the native speech shim.
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const src = path.join(root, 'web');
const out = path.join(root, 'www');

fs.rmSync(out, { recursive: true, force: true });
fs.mkdirSync(path.join(out, 'fonts'), { recursive: true });
for (const f of fs.readdirSync(src)) fs.copyFileSync(path.join(src, f), path.join(out, f));

// Fonts: copy woff2 files from @fontsource-variable packages and write fonts.css
const faces = [];
function addFont(pkg, family, base, style, weights) {
  const dir = path.join(root, 'node_modules', pkg, 'files');
  if (!fs.existsSync(dir)) { console.warn(`! ${pkg} not installed - ${family} falls back to system font`); return; }
  const file = fs.readdirSync(dir).find(n => n.startsWith(base + '-latin-wght-') && n.includes(style) && n.endsWith('.woff2'));
  if (!file) { console.warn(`! no latin ${style} woff2 found in ${pkg}`); return; }
  fs.copyFileSync(path.join(dir, file), path.join(out, 'fonts', file));
  faces.push(`@font-face{font-family:'${family}';font-style:normal;font-weight:${weights};font-display:swap;src:url(fonts/${file}) format('woff2')}`);
}
addFont('@fontsource-variable/fraunces', 'Fraunces', 'fraunces', 'normal', '100 900');
addFont('@fontsource-variable/inter', 'Inter', 'inter', 'normal', '100 900');
fs.writeFileSync(path.join(out, 'fonts.css'), faces.join('\n') + '\n');

// No service worker in the native app: files are already local.
fs.rmSync(path.join(out, 'sw.js'), { force: true });

let html = fs.readFileSync(path.join(out, 'index.html'), 'utf8');
html = html.replace(/<link[^>]+fonts\.(googleapis|gstatic)\.com[^>]*>\s*/g, '');
html = html.replace('<title>', '<link rel="stylesheet" href="fonts.css">\n<script src="native-speech.js"></script>\n<title>');
fs.writeFileSync(path.join(out, 'index.html'), html);
console.log('www/ ready');
