/* Makes the app's existing Web Speech code work inside the Android app.
   Android WebView has no SpeechRecognition, so on a native build we provide a
   drop-in window.SpeechRecognition backed by @capacitor-community/speech-recognition.
   In a normal browser this file does nothing. */
(function () {
  var cap = window.Capacitor;
  if (!cap || !cap.isNativePlatform || !cap.isNativePlatform()) return;
  var P = cap.Plugins && cap.Plugins.SpeechRecognition;
  if (!P) return;

  function NativeSR() {
    this.lang = 'en-US';
    this.interimResults = true;
    this.continuous = false;
    this.maxAlternatives = 1;
    this.onstart = this.onresult = this.onerror = this.onend = null;
    this._active = false;
    this._aborted = false;
    this._handles = [];
    this._last = [];
  }

  NativeSR.prototype._emit = function (name, ev) {
    try { if (typeof this[name] === 'function') this[name](ev || {}); } catch (e) { console.error(e); }
  };

  NativeSR.prototype._results = function (matches, isFinal) {
    var alts = (matches || []).map(function (t) { return { transcript: t, confidence: 0.9 }; });
    if (!alts.length) return null;
    var res = alts; res.isFinal = !!isFinal;
    return { results: [res], resultIndex: 0 };
  };

  NativeSR.prototype._cleanup = function () {
    this._handles.forEach(function (h) { try { h.remove(); } catch (e) {} });
    this._handles = [];
  };

  NativeSR.prototype._finish = function () {
    if (!this._active) return;
    this._active = false;
    if (!this._aborted && this._last.length) this._emit('onresult', this._results(this._last, true));
    this._cleanup();
    this._emit('onend');
  };

  NativeSR.prototype.start = function () {
    var self = this;
    if (self._active) throw new Error('already started');
    self._active = true; self._aborted = false; self._last = [];
    var started = false;
    function markStarted() { if (!started) { started = true; self._emit('onstart'); } }

    (async function () {
      try {
        var perm = await P.requestPermissions();
        if (!perm || perm.speechRecognition !== 'granted') {
          self._emit('onerror', { error: 'not-allowed' }); self._finish(); return;
        }
        var avail = await P.available();
        if (avail && avail.available === false) {
          self._emit('onerror', { error: 'service-not-allowed' }); self._finish(); return;
        }
        self._handles.push(await P.addListener('partialResults', function (d) {
          if (self._aborted || !d || !d.matches) return;
          markStarted();
          self._last = d.matches;
          if (self.interimResults) self._emit('onresult', self._results(d.matches, false));
        }));
        self._handles.push(await P.addListener('listeningState', function (d) {
          if (!d) return;
          if (d.status === 'started') markStarted();
          if (d.status === 'stopped') self._finish();
        }));
        await P.start({
          language: self.lang,
          maxResults: Math.max(1, self.maxAlternatives || 1),
          partialResults: true,
          popup: false
        });
        markStarted();
      } catch (e) {
        self._emit('onerror', { error: 'audio-capture', message: String(e && e.message || e) });
        self._finish();
      }
    })();
  };

  NativeSR.prototype.stop = function () { try { P.stop(); } catch (e) {} };
  NativeSR.prototype.abort = function () { this._aborted = true; try { P.stop(); } catch (e) {} };

  window.SpeechRecognition = NativeSR;
  window.webkitSpeechRecognition = NativeSR;
})();
